<?php

$connect = new mysqli("localhost","u802369894_obrm","Obrm2022","u802369894_obrm_db");


if($connect){
	
}else{
	
	echo "connection failed";
	exit();
}

